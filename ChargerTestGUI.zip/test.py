int_val = 12
  
# converting to string
str_val = str(int_val)
  
# converting string to bytes
byte_val = str_val.encode()
print(byte_val)
